# Team Photos

Drop member photos here. Recommended: square images, minimum 128×128px.

Filename convention: `firstname-lastname.jpg`

Then in `lib/data.ts`, update the `photo` field from `null` to the path:
```ts
photo: "/team/firstname-lastname.jpg"
```
