# Logos

Drop your logo files here:

- `sb.png` — IEEE SOA Student Branch logo
- `cs.png` — IEEE Computer Society logo

Then follow the instructions in the root `README.md` to wire them in.
